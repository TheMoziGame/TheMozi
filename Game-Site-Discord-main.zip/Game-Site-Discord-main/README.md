<h1 align="center">
    <br>
  Akatori Game WebSite
  <br>
  <br>
  <img src="https://cdn.discordapp.com/attachments/936742811116667000/942813196526432276/unknown.png">
</h1>

# Installation

**It's very simple:** 

- Just put your discord url in the ```index.html``` and ``about-game.html``
- Add your .exe in the game file and change the link in the ```index.html``` and `about-game.html`
